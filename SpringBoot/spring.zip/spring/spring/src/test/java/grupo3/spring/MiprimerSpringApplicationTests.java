package grupo3.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiprimerSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
