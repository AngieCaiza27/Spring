package grupo3.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiprimerSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiprimerSpringApplication.class, args);
	}

}
